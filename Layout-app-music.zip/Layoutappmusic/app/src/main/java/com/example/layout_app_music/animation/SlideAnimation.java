package com.example.layout_app_music.animation;

public class SlideAnimation {
    private int hinh;

    public SlideAnimation(int Hinh){
        this.hinh = Hinh;
    }

    public int getHinh() {
        return hinh;
    }
}
