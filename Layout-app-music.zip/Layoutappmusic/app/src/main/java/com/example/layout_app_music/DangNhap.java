package com.example.layout_app_music;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class DangNhap extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dangnhap);
    }
}
